#include "Stack.h"

#include <iostream>

bool Stack::IsFull()
{
	if (top + 1 >= MAXSIZE) return true;
	else return false;
}

bool Stack::IsEmpty()
{
	if (top < 0) return true;
	else return false;
}

void Stack::Push(float Xposition, float Yposition)
{
	if (!IsFull())
	{
		top = top + 1;
		stack[top][0] = Xposition;
		stack[top][1] = Yposition;
	}
	else std::cout << "your stack is full" << std::endl;
}

void Stack::Pop()
{
	if (!IsEmpty())
	{
		top = top - 1;
	}
	else std::cout << "your stack is empty" << std::endl;

}

void Stack::Display()
{
	if (!IsEmpty())
		for (int i = top; i >= 0; i--)
			std::cout << stack[i][0] << '\t' << stack[i][1] << std::endl;
}

bool Stack::Find(float Xposition, float Yposition)
{
	if (IsEmpty())
		return false;
	else
	{
		for (int i = 0; i <= top; i++)
		{
			if (stack[i][0] == Xposition)
				if (stack[i][1] == Yposition)
					return true;
		}
		return false;
	}

}