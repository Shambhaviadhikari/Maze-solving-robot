#pragma once

class Stack
{
private:
	const int MAXSIZE = 70;

private:
	bool IsFull();
	bool IsEmpty();

public:
	int top = -1;
	float stack[70][2];

public:
	void Push(float Xposition, float Yposition);
	void Pop();
	void Display();

	bool Find(float Xposition, float Yposition);
};