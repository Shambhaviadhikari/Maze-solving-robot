#include "MazeSolvingCar.h"

#include <iostream>



MazeSolvingCar::MazeSolvingCar()
	:vbo(vertices, sizeof(vertices)), ibo(indices, 6), shader("res/shaders/MazeSolvingCar.shader"), texture("res/textures/omniwheel_vehicle.png"), model(1.0),
	projection(1.0)
{
	layout.Push<float>(2);
	layout.Push<float>(2);

	PlaceToCurrentPosition();

	projection = glm::ortho(0.0f, 900.0f, 0.0f, 900.0f);
	shader.Bind();
	shader.SetUniform1i("texture0", 1);
	shader.SetUniformMat4f("projection", projection);

	NodeStack.Push(Xposition, Yposition);

}

void MazeSolvingCar::Draw()
{
	vao.Bind();
	vao.AddBuffer(vbo, layout);
	
	texture.Bind(1);

	shader.Bind();

	shader.SetUniformMat4f("model", model);

	renderer.Draw(vao, ibo, shader);
}


void MazeSolvingCar::GetPixel(int x, int y)
{
	//glReadBuffer(GL_FRONT);

	//glPixelStorei(GL_PACK_ALIGNMENT, 1);
	unsigned char pixel_r;
	glReadPixels(x, y, 1, 1, GL_RED, GL_UNSIGNED_BYTE, &pixel_r);

	std::cout << int(pixel_r) << std::endl;
}


void MazeSolvingCar::PlaceToCurrentPosition()
{
	model = glm::mat4(1.0);
	model = glm::translate(model, glm::vec3(-width / 2, -height / 2, 0.0f));	//making the centre of car at the bottom left corner
	model = glm::translate(model, glm::vec3(Xposition, Yposition, 0.0f));	//placing the car at the start point

}

void MazeSolvingCar::MoveForward()
{
	Yposition += move_pixels;
	model = glm::translate(model, glm::vec3(0.0f, move_pixels, 0.0f));
}

void MazeSolvingCar::MoveBackward()
{
	Yposition -= move_pixels;
	model = glm::translate(model, glm::vec3(0.0f, -move_pixels, 0.0f));
}

void MazeSolvingCar::MoveLeft()
{
	Xposition -= move_pixels;
	model = glm::translate(model, glm::vec3(-move_pixels, 0.0f, 0.0f));
}

void MazeSolvingCar::MoveRight()
{
	Xposition += move_pixels;
	model = glm::translate(model, glm::vec3(move_pixels, 0.0f, 0.0f));
}



 bool MazeSolvingCar::IsThereForwardWay()
 {
	 unsigned char pixel_r[10];		//looks 10 pixel to find if there is wall
	 glReadPixels(Xposition, Yposition + height / 2+1, 1, 10, GL_RED, GL_UNSIGNED_BYTE, pixel_r);
	 unsigned char temp = 255;
	 for (int i = 0; i < 10; i++)
		 temp = temp & pixel_r[i];
	 return (int(temp) == 255) ? true : false;
 }

 bool MazeSolvingCar::IsThereBackwardWay()
 {
	 unsigned char pixel_r[10];		//looks 10 pixel to find if there is wall
	 glReadPixels(Xposition, Yposition - height / 2 - 1-10, 1, 10, GL_RED, GL_UNSIGNED_BYTE, pixel_r);
	 unsigned char temp = 255;
	 for (int i = 0; i < 10; i++)
		 temp = temp & pixel_r[i];
	 return (int(temp) == 255) ? true : false;
 }

 bool MazeSolvingCar::IsThereLeftway()
 {
	 unsigned char pixel_r[10];		//looks 10 pixel to find if there is wall
	 glReadPixels(Xposition - width / 2 - 1 - 10, Yposition, 10, 1, GL_RED, GL_UNSIGNED_BYTE, pixel_r);
	 unsigned char temp = 255;
	 for (int i = 0; i < 10; i++)
		 temp = temp & pixel_r[i];
	 return (int(temp) == 255) ? true : false;
 }

 bool MazeSolvingCar::IsThereRightWay()
 {
	 unsigned char pixel_r[10];		//looks 10 pixel to find if there is wall
	 glReadPixels(Xposition + width / 2 + 1, Yposition, 10, 1, GL_RED, GL_UNSIGNED_BYTE, pixel_r);
	 unsigned char temp = 255;
	 for (int i = 0; i < 10; i++)
		 temp = temp & pixel_r[i];
	 return (int(temp) == 255) ? true : false;
 }


 bool MazeSolvingCar::IsCurrentNodeInNodeStack()
 {
	 return NodeStack.Find(Xposition, Yposition);
 }



 bool MazeSolvingCar::IsForwardNodeInNodeStack()
 {
	return NodeStack.Find(Xposition, Yposition + move_pixels);
 }

 bool MazeSolvingCar::IsForwardNodeInDeadNodeStack()
 {
	 return DeadNodeStack.Find(Xposition, Yposition + move_pixels);
 }



 bool MazeSolvingCar::IsRightNodeInNodeStack()
 {
	 return NodeStack.Find(Xposition + move_pixels, Yposition);
 }

 bool MazeSolvingCar::IsRightNodeInDeadNodeStack()
 {
	 return DeadNodeStack.Find(Xposition + move_pixels, Yposition);
 }



 bool MazeSolvingCar::IsLeftNodeInNodeStack()
 {
	 return NodeStack.Find(Xposition - move_pixels, Yposition);
 }

 bool MazeSolvingCar::IsLeftNodeInDeadNodeStack()
 {
	 return DeadNodeStack.Find(Xposition - move_pixels, Yposition);
 }



 bool MazeSolvingCar::IsBackwardNodeInNodeStack()
 {
	 return NodeStack.Find(Xposition, Yposition - move_pixels);
 }

 bool MazeSolvingCar::IsBackwardNodeInDeadNodeStack()
 {
	 return DeadNodeStack.Find(Xposition, Yposition - move_pixels);
 }





 void MazeSolvingCar::FindPath()
 {
	 //all the squares are nodes
	 //Depth first search with FRLB i.e Forward -> Right -> Left -> Backward
	 if ((Xposition == EndPositionX) && (Yposition == EndPositionY));
	 else
	 {
		 if (IsThereForwardWay() && !IsForwardNodeInNodeStack() && !IsForwardNodeInDeadNodeStack())
		 {
			 MoveForward();
			 if (!IsCurrentNodeInNodeStack())
				 NodeStack.Push(Xposition, Yposition);	//Store Current Node In Node Stack

		 }
		 else if (IsThereRightWay() && !IsRightNodeInNodeStack() && !IsRightNodeInDeadNodeStack())
		 {
			 MoveRight();
			 if (!IsCurrentNodeInNodeStack())
				 NodeStack.Push(Xposition, Yposition);	//Store Current Node In Node Stack

		 }
		 else if (IsThereLeftway() && !IsLeftNodeInNodeStack() && !IsLeftNodeInDeadNodeStack())
		 {
			 MoveLeft();
			 if (!IsCurrentNodeInNodeStack())
				 NodeStack.Push(Xposition, Yposition);	//Store Current Node In Node Stack

		 }
		 else if (IsThereBackwardWay() && !IsBackwardNodeInNodeStack() && !IsBackwardNodeInDeadNodeStack())
		 {
			 MoveBackward();
			 if (!IsCurrentNodeInNodeStack())
				 NodeStack.Push(Xposition, Yposition);	//Store Current Node In Node Stack

		 }

		 //then it is a ToDeathNode;
		 else
		 {
			 DeadNodeStack.Push(Xposition, Yposition);
			 NodeStack.Pop();
			 Xposition = NodeStack.stack[NodeStack.top][0];
			 Yposition = NodeStack.stack[NodeStack.top][1];
			 PlaceToCurrentPosition();

		 }

		 NodeStack.Display();
		 std::cout << std::endl << std::endl;
		 DeadNodeStack.Display();
		 std::cout << std::endl << std::endl << "/////////////////////////////////////////////////////////////////" << std::endl << std::endl;

	 }
 }





 void MazeSolvingCar::MoveInPath()
 {
	 if (node_count <= NodeStack.top)
	 {
		 Xposition = NodeStack.stack[node_count][0];
		 Yposition = NodeStack.stack[node_count][1];
		 PlaceToCurrentPosition();
		 node_count++;
	 }
 }
