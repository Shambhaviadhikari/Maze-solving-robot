#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>


#include "Renderer.h"
#include "Maze.h"
#include "MazeSolvingCar.h"

#define RefreshRate 20	//should be factor of 60

#define WIDTH 900
#define HEIGHT 900


GLFWwindow* window;


int initialization();

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
bool keys[1024];


int main(void)
{
	if (initialization() == -1)
		return -1;
	Renderer renderer;

	Maze maze;
	MazeSolvingCar car;


	while (glfwWindowShouldClose(window) == 0)
	{
		renderer.Clear();
		//print cursor coordinates
		/*
		{
			double xpos, ypos;
			glfwGetCursorPos(window, &xpos, &ypos);
			int xposint = xpos;
			int yposint = ypos;
			std::cout << "Cursor Position at (" << xposint << ", " << HEIGHT - yposint << ")" << std::endl;
			car.GetPixel(xposint, HEIGHT - yposint);
		}
		*/
		/*
		if (car.IsThereForwardWay())
			car.MoveForward();
		else if (car.IsThereRightWay())
			car.MoveRight();

		else if (car.IsThereLeftway())
			car.MoveLeft();

		else
			car.MoveBackward();
			*/
		if (keys[GLFW_KEY_SPACE])
			car.FindPath();
			
		
		maze.Draw();
		/*
		if (keys[GLFW_KEY_W])
			car.MoveForward();
		if (keys[GLFW_KEY_S])
			car.MoveBackward();
		if (keys[GLFW_KEY_A])
			car.MoveLeft();
		if (keys[GLFW_KEY_D])
			car.MoveRight();
		*/
		
		car.Draw();

		if (keys[GLFW_KEY_ENTER])
			car.MoveInPath();

		
		glfwPollEvents();
		glfwSwapBuffers(window);
		//car.FindPath();
		}

	glfwTerminate();
	return 0;
}


int initialization()
{
	if (!glfwInit())
	{
		std::cout << "Error initializing glfw" << std::endl;
		return -1;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	glfwWindowHint(GLFW_OPENGL_DEBUG_CONTEXT, GL_TRUE);

	window = glfwCreateWindow(WIDTH, HEIGHT, "Maze Solving Robot SIMULATION", NULL, NULL);
	if (!window)
	{
		std::cout << "Error opening window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);	// make current window the Opengl rendering context

	glfwSwapInterval(60/RefreshRate);	//synchronizing with monitor frequency i.e 60Hz

	if (glewInit() != GLEW_OK)	// glewInit() should be called after a valid OpenGL rendering context is created
		std::cout << "Error while initializing glew" << std::endl;

	glEnable(GL_DEBUG_OUTPUT);
	glDebugMessageCallback(MessageCallback, 0);

	std::cout << "Renderer: "<< glGetString(GL_RENDERER) << std::endl;
	std::cout << glGetString(GL_VERSION) << std::endl;	// print opengl version and graphics card version

	glfwSetKeyCallback(window, key_callback);


	//for glReadPixels
	glReadBuffer(GL_FRONT);
	glPixelStorei(GL_PACK_ALIGNMENT, 1);

	return 0;
}


void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	if (key == GLFW_KEY_ESCAPE)
		glfwSetWindowShouldClose(window, 1);
	else
	{
		if (action == GLFW_PRESS)
			keys[key] = true;
		else if (action == GLFW_RELEASE)
			keys[key] = false;
	}
}