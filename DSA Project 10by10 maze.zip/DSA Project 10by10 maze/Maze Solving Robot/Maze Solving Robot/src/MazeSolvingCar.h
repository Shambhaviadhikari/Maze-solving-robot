#pragma once

#include "Renderer.h"
#include "VertexBuffer.h"
#include "VertexBufferLayout.h"
#include "IndexBuffer.h"
#include "Shader.h"
#include "Texture.h"

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

#include "glm/gtx/string_cast.hpp"

#include "Stack.h"

class MazeSolvingCar
{
private:
	const float StartPositionX = 493.5f;
	const float StartPositionY = 53.5f;

	const float EndPositionX = 405.5f;
	const float EndPositionY = 845.5f;

	const float width = 70.0f;
	const float height = 70.0f;

	float Xposition = StartPositionX;
	float Yposition = StartPositionY;

	const int move_pixels = 76+10+2;

	Stack NodeStack;
	int node_count = 0;

	Stack DeadNodeStack;


	const float vertices[16] = {
	 0.0f,   0.0f,  0.0f, 0.0f,
	width,   0.0f,  1.0f, 0.0f,
	width,  height, 1.0f, 1.0f,
	 0.0f,  height, 0.0f, 1.0f
	};

	const unsigned int indices[6] = {
	0, 1, 2,
	0, 2, 3
	};

	VertexBuffer vbo;
	IndexBuffer ibo;
	VertexBufferLayout layout;
	VertexArray vao;

	Shader shader;
	Texture texture;
	Renderer renderer;

	glm::mat4 model;
	glm::mat4 projection;

private:
	void PlaceToCurrentPosition();

	void MoveForward();
	void MoveBackward();
	void MoveLeft();
	void MoveRight();


	bool IsThereForwardWay();
	bool IsThereBackwardWay();
	bool IsThereRightWay();
	bool IsThereLeftway();

	bool IsCurrentNodeInNodeStack();


	bool IsForwardNodeInNodeStack();
	bool IsForwardNodeInDeadNodeStack();

	bool IsRightNodeInNodeStack();
	bool IsRightNodeInDeadNodeStack();

	bool IsLeftNodeInNodeStack();
	bool IsLeftNodeInDeadNodeStack();

	bool IsBackwardNodeInNodeStack();
	bool IsBackwardNodeInDeadNodeStack();

public:
	MazeSolvingCar();

	void Draw();

	void GetPixel(int x, int y);
	



	//path finding
	void FindPath();

	
	//moving in path
	void MoveInPath();
};
