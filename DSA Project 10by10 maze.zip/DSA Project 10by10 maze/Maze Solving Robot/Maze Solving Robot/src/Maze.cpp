#include "Maze.h"



Maze::Maze()
	:vbo(vertices, sizeof(vertices)), ibo(indices, 6), shader("res/shaders/Maze.shader"), texture("res/textures/10by10maze.png"), projection(1.0)
{
	layout.Push<float>(2);
	layout.Push<float>(2);

	projection = glm::ortho(0.0f, width, 0.0f, height);
	shader.Bind();
	shader.SetUniformMat4f("projection", projection);
}

void Maze::Draw()
{
	vao.Bind();
	vao.AddBuffer(vbo, layout);

	texture.Bind(0);

	shader.Bind();
	shader.SetUniform1i("texture0", 0);

	renderer.Draw(vao, ibo, shader);
}